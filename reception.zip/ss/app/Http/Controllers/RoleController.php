<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class RoleController extends Controller
{
    function getRole($email){
       return  DB::table('roles')->where('email', $email)->value('role');
    }
}
