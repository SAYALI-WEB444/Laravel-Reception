<?php

namespace App\Http\Controllers;
use App\Product;
use Illuminate\Http\Request;
use App\Http\Controllers\RoleController;
use Auth;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class ProductController extends Controller
{

    /**     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $product = Product::query();
        $searchParamater= ($request->get("search"));
        if(!empty($searchParamater)){
            $search_criteriea = "";
            if($searchParamater[0] == "+" || is_numeric($searchParamater[0])){
                $search_criteriea = "patient_mobile";
            }
            else{
                $search_criteriea= "patient_name";
            }
            //Go for exact term to avoid expose of data
            $product->where("$search_criteriea",  '=',$searchParamater );
          //  $product->where("$search_criteriea",  'like',"%".$searchParamater."%" );
            $products =  $product->orderBy('id', 'DESC')->paginate(10);
            return view('products.index',compact('products'))
                ->with('i', (request()->input('page', 1) - 1) * 20);

        }
        $search_criteriea = "";
        $roleObject = new RoleController();
        $role =  $roleObject->getRole(Auth::user()->email);
        if($role == "reception"){
            $search_criteriea = "business_developer";
        }else if($role == "doctor"){
            $search_criteriea = "doctor_name";
        }else {
            return "We dont recognise your role, please contact your manager      " . Auth::user()->email;
        }

        $product->where($search_criteriea,  '=',Auth::user()->email);

        $products =  $product->orderBy('id', 'DESC')->paginate(10);
        /*$products = Product::latest()->paginate(20); */
        return view('products.index',compact('products'))
            ->with('i', (request()->input('page', 1) - 1) * 20);
    }

    public function mySearch(Request $request)
    {
      
        if($request->has('search')){
            $product = Product::search($request->get('search'))->get();
        }else{
            $product = Product::get();
        }


        return view('my-search', compact('product'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('products.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'patient_name'  => 'required'  ,
            'patient_mobile' => 'required' ,
            'patient_address' => 'required',
            'status'  => 'required',
            'business_developer',
            'doctor_name',
            'doctor_consultation'=> 'nullable',
            'delivery'=> 'nullable',
            'problem_of_patient'=> 'nullable',
            'medicines'=> 'nullable',
            'total_billing'=> 'nullable',
            'mode_of_payment'=> 'nullable',
            'patient_enrol_date',
            'discount'=> 'nullable',
            'pincode'=> 'nullable',
            'state'=> 'nullable',
            'order_n' => 'nullable',
            'nearest_city'=> 'nullable',
            'patient_available'=> 'nullable',
            'to'=> 'nullable',
            'tracking_url'=> 'nullable',
            'doctor_validation'=> 'nullable',
            'validators'=> 'nullable',
            'delivery_date'=> 'nullable',
            'followup_date'=> 'nullable',
            'order_number'


        ]);

        Product::create($request->all());

        return redirect()->route('products.index')
                        ->with('success','Patient created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        return view('products.show',compact('product'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        return view('products.edit',compact('product'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        $request->validate([
            'patient_name',
            'patient_mobile',
            'patient_address',
            'status',
            'business_developer',
            'doctor_name',
            'doctor_consultation',
            'delivery',
            'problem_of_patient',
            'medicines',
            'total_billing',
            'mode_of_payment',
            'patient_enrol_date',
            'discount',
            'pincode',
            'state' ,
            'order_n',
            'nearest_city',
            'patient_available',
            'to' => 'required',
            'tracking_url',
            'doctor_validation',
            'validators',
            'delivery_date',
            'followup_date',
            'order_number'
        ]);

        $product->update($request->all());

        return redirect()->route('products.index')
                        ->with('success','Patient updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        $product->delete();

        return redirect()->route('products.index')
                        ->with('success','Patient deleted successfully');
    }
}
