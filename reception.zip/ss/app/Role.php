<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    protected $fillable = [
        'name',
        'email',
        'mobile',
        'clinic',
        'email',
        'role',
        'manager email',
        'hrs email',
        'designation',
        'city'
    ];
}
