<?php

namespace App;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;
use Nicolaslopezj\Searchable\SearchableTrait;

class Product extends Model
{
    protected $fillable = [
        'patient_name',
        'patient_mobile',
        'patient_address',
        'status',
        'business_developer',
        'doctor_name',
        'doctor_consultation',
        //'delivery',
        'problem_of_patient',
        'medicines',
        'total_billing',
        'mode_of_payment',
        'patient_enrol_date',
        'discount',
        'pincode',
        'state',
       // 'order_n',
        'nearest_city',
        'patient_available',
        'to',
        'tracking_url',
        'doctor_validation',
        'validators',
        'delivery_date',
        'followup_date',
        'order_number'

    ];



}
