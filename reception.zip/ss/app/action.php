<?php
print_r ($_POST['languages']); ?>
    ?><?php
