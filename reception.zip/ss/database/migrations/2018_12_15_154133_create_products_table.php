<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->increments('id');
            $table->string('patient_name');
            $table->string('patient_mobile');
            $table->string('patient_address');
            $table->string('status');
            $table->string('business_developer');
            $table->string('doctor_name');
            $table->string('doctor_consultation');
           // $table->string('delivery');
            $table->string('problem_of_patient');
            $table->string('medicines');
            $table->string('total_billing');
            $table->string('mode_of_payment');
            $table->string('patient_enrol_date');
            $table->string('discount');
            $table->string('pincode');
            $table->string('state');
           // $table->string('order_n');
            $table->string('nearest_city');
            $table->string('patient_available');
            $table->string('to');
            $table->string('tracking_url');
            $table->string('doctor_validation');
            $table->string('validators');
            $table->string('delivery_date');
            $table->string('followup_date');
            $table->string('order_number');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
