
<div class="fa-pull-left">
    <a class="btn btn-primary" href="{{ route('products.index') }}">Back</a>
</div>
