@extends('products.layout')

@section('content')


    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
    <span>
    <div class="row">
        <div class="col-lg-10 margin-tb">
            <div class="pull-right">
            </div>
            <br>
            <div class="pull-left">
            <a class="btn btn-success" href="{{ route('products.create') }}">Add Patient</a>
                   <a class="btn btn-success" href="{{ route('home') }}">Call</a>

                <!--<a class="btn buttons-excel buttons-html5 btn-default" tabindex="0" aria-controls="DataTables_Table_0" href="#"><span>Excel</span></a>-->
                <!--<a class="btn buttons-csv buttons-html5 btn-default" tabindex="0" aria-controls="DataTables_Table_0" href="#"><span>CSV</span></a>-->
            </div>
            <br>

            <br>
        </div>
    </div>

<div class="row">
    <div class="col-lg-10 margin-tb">
        <div class="pull-right">

    <form method="GET" action="">
        <div class="row">
            <div class="col-md-10">
                <input type="text" name="search" class="form-control" placeholder="Search Patient" value="{{ old('search') }}">
            </div>
            <div class="col-md-2">
                <button class="btn btn-success">Search</button>


            </div>
        </div>
        </form>
    <br></div>
    @if ($message = Session::get('success'))
            <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
        @endif


    <!--<table class="table table-bordered">-->

        @foreach ($products as $product)

            <table class="table table-bordered data-table">

   @if (   !app('request')->input('search') || (

      ( $product->doctor_name == Auth::user()->email || $product->business_developer == Auth::user()->email) )
      )
                    <a class="btn btn-primary" href="{{ route('products.edit',$product->id ) }}">Edit</a>
                @endif
   <br>
</br>
   <form action="" method="POST">

<tr>
            <th>No</th>
            <th>Patient_Name</th>
            <th>Patient_Mobile</th>
            <th>Patient_Address</th>
            <th>Status</th>
            <th>Business_Developer</th>
            <th>Doctor_Name</th>
            <th>Doctor_Consultation</th>
            <!--<th>Delivery</th>-->
            <th>Problem_of_Patient</th>
            <th>Patient_Medicines</th>
            <th>Total_Billing</th>
            <th>Mode_of_Payment</th>
            <th>Patient_Enrol_Date</th>
            <th>Discount</th>
            <th>Pincode</th>
            <th>State</th>
            <!--<th>Order_N</th>-->
            <th>Nearest_City</th>
            <th>Patient_Available</th>
            <th>To</th>
            <th>Tracking_Url</th>
            <th>Doctor_Validation</th>
            <th>Validators</th>
            <th>Delivery_Date</th>
            <th>Followup_Date</th>
            <th>Order_Number</th>
   </tr>
            <tr>
            <td>{{ ++$i  }}</td>
            <td>{{$product->patient_name }}</td>
            <td>{{$product->patient_mobile }}</td>
            <td>{{$product->patient_address }}</td>
            <td>{{$product->status }}</td>
            <td>{{$product->business_developer }}</td>
            <td>{{$product->doctor_name }}</td>
            <td>{{$product->doctor_consultation }}</td>
           <!-- <td>{{$product->delivery }}</td>-->
            <td>{{$product->problem_of_patient }}</td>
            <td>{{$product->medicines }}</td>
            <td>{{$product->total_billing }}</td>
            <td>{{$product->mode_of_payment }}</td>
            <td>{{$product->patient_enrol_date }}</td>
            <td>{{$product->discount }}</td>
            <td>{{$product->pincode }}</td>
            <td>{{$product->state }}</td>
           <!--<td>{{$product->order_n}}</td>-->
            <td>{{$product->nearest_city}}</td>
            <td>{{$product->patient_available}}</td>
            <td>{{$product->to}}</td>
            <td>{{$product->tracking_url}}</td>
            <td>{{$product->doctor_validation}}</td>
            <td>{{$product->validators}}</td>
            <td>{{$product->delivery_date}}</td>
            <td>{{$product->followup_date}}</td>
            <td>{{$product->order_number}}</td>



                    @csrf
                    </form>



        </tr>
        @endforeach
    </table>

    {!! $products->links() !!}

@endsection














