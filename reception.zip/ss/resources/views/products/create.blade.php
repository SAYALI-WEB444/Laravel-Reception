@extends('products.layout')
@section('content')
    <?php
    use App\Http\Controllers\RoleController;
    $roleObject = new RoleController();
    $role =  $roleObject -> getRole(Auth::user()->email);
    ?>

    <script>
        /*$(function(){
            $('#demo').multiselect();
        });*/

        $(window).load(
            $(function() {
                setupCreatePage(
                    <?php echo "'" . $role . "'" ?>
                );
                setupEditPage(
                    <?php echo "'" . $role . "'" ?>
                );

            })

        )
    </script>

    <div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <br>
            <h2>Add New Patients</h2>
        </div>
        <br>
        <div class="fa-pull-left">
            <a class="btn btn-primary" href="{{ route('products.index') }}">Back</a>
        </div>
    </div>
</div>
@if ($errors->any())
    <div class="alert alert-danger">
        <strong>Whoops!</strong>There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{route('products.store') }}" method="POST">
    @csrf
     <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Patient_Name:</strong>
                <input type="text" name="patient_name" class="form-control" placeholder="Enter Name">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Patient_Mobile:</strong>
                <input type="tel" name="patient_mobile" class="form-control" placeholder="Enter Mobile">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Patient_Address:</strong>
                <input type="text" name="patient_address" class="form-control" placeholder="Enter Address">
            </div>
        </div>
<!--<div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Status:</strong>
                <input type="text" name="status" class="form-control" placeholder="Enter Status">
            </div>
        </div>-->
        <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group" {{ $errors->has('status') ? 'has-error' : ''}}>
                                                <strong>Status</strong>
                                                <select class="form-control" name="status" value="{{ old('status') }}">
                                                    <option selected></option>
                                                    <?php
                                                     if($role == "doctor"){

                                                     echo "
                                                    <option value='Validation done by Doctor (d) - set this status if you are telling price and medicines to patient and you are absolutely sure that patient is not going to refuse the delivery, otherwise set schedule for delivery'>Validation done by Doctor (d) - set this status if you are telling price and medicines to patient and you are absolutely sure that patient is not going to refuse the delivery, otherwise set schedule for delivery</option>
                                                    <option value='Consultation Done - Do Not Deliver Medicines'>Consultation Done - Do Not Deliver Medicines</option>
                                                    <option value='Call back'>Call back</option>
                                                    <option value='Patient not reachable (d) - retry 1'>Patient not reachable (d) - retry 1</option>
                                                    <option value='Patient not reachable (d) - retry 2'>Patient not reachable (d) - retry 2</option>
                                                    <option value='Patient not reachable (d) - retry 3'>Patient not reachable (d) - retry 3</option>
                                                    <option value='Ask for Reports'>Ask for Reports</option>

                                                    <option value='Reconvince Patient (d)'>ReConvince Patient (d)</option>";
                                                    }
                                                     echo "<option value='New'>New</option>
                                                    <option value='Followup'> Followup</option>
                                                    <option value='Duplicate Entry'>Duplicate Entry</option>";


                                                    ?>
                                                </select>
                                                {!! $errors->first('status', '<small class="text-danger">:message </small>') !!}
                                            </div>
                                            </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Business_Developer:</strong>
                <input type="email" id="business_developer", name="business_developer" class="form-control">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">

                    <?php
                        if($role == "doctor"){
                            echo "
                                <div class='form-group'>
                                     <strong>Doctor_Name:</strong>
                                              <input type='email' id='doctor_name' name='doctor_name' class='form-control'>
                               </div>
                            ";
                        }else{


                        echo "

                                 <div  input type='email' id='doctor_name' class='form-group' name='doctor_name' >
                                                                    <strong> Doctor_Name<strong>
                                                                                    <select class='form-control' name='doctor_name' id='doctor_name' >
                                                                                        <option selected>Select Doctor</option>
                                                                                        <option value='s@gmail.com'>s@gmail.com</option>
                                                                                        <option value='d@gmail.com'>d@gmail.com</option>
                                                                                        <option value='priya'>priya</option>
                                                                                        <option value='Namrata'>Namrata</option>
                                                                                    </select>

                                </div>
                               ";
                        } ?>
         </div>
        <!--<div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Doctor_Consultation Date:</strong>
                <input type="text" id="doctor_consultation" name="doctor_consultation" class="form-control" placeholder="Doctor Consultation">
            </div>
        </div>-->





         <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Problem_Of_Patient:</strong>
                <input type="text" name="problem_of_patient" class="form-control" placeholder="Enter Problems Of Patient">
            </div>
        </div>
         <!--<div class="col-xs-12 col-sm-12 col-md-12">
             <strong>Select Medicines:</strong>
             <select class="selectpicker"multiple data-live-search="true">
                 <option value="srdp talet:2 pack: 200">srdp talet:2 pack: 200</option>
                 <option value="srdp talet:3 pack: 300">srdp talet:3 pack: 300</option>
                 <option value=">srdp talet:4 pack:400">srdp talet:4 pack:400</option>
                 <option value="srdp talet:5 pack: 500">srdp talet:5 pack: 500</option>
                 <option value="srdp oil">srdp oil</option>
                 <option value="potli">potli</option>
             </select>
         </div>-->


         <div class="col-xs-12 col-sm-12 col-md-12">
             <strong>Medicines:</strong><select id="demo" multiple="multiple">
                 <option value="srdp talet:2 pack:200">srdp talet:2 pack:200</option>
                 <option value="srdp talet:3 pack:300">srdp talet:3 pack:300</option>
                 <option value="srdp talet:4 pack:400">srdp talet:4 pack:400</option>
                 <option value="srdp talet:5 pack:500">srdp talet:5 pack:500</option>
                 <option value="srdp oil:1   pack:100">srdp oil:1 pack:100</option>
                 <option value="potli:1 pack:50">potli:1 pack:50</option>
             </select>
             <div class="form-group">
                 <input type="text" id="medicines" name="medicines" class="form-control" placeholder="">

             </div>
         </div>


     </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Total_Billing:</strong>
                <input type="text" id="totalbill" name="total_billing" class="form-control" placeholder="Total  Billing">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Mode_of_Payment:</strong>
                <select class="form-control" name="mode_of_payment" id="ode_of_payment"  placeholder="" >
                    <option value="COD">COD</option>
                    <option value="POD">POD</option>
                </select>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Patient_Enrol_Date:</strong>
                <input type="text" id="patient_enrol_date" name="patient_enrol_date" class="form-control" placeholder="Patient Enrol Date">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Discount:</strong>
                <input type="number" id="discount" name="discount" class="form-control" placeholder="%">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Pincode:</strong>
                <input type="number" name="pincode" class="form-control" placeholder="Enter Pincode">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>State:</strong>
                <input type="text" name="state" class="form-control" placeholder="State">
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
               <!-- <strong>Nearest_City:</strong>-->
                <input type="text" name="nearest_city" class="form-control" placeholder="Nearest City"  style="display: none">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Patient_Available:</strong>
                <input type="text" name="patient_available" class="form-control" placeholder="Patient Available">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>To:</strong>
                <input type="text" name="to" class="form-control" placeholder="To">
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Order_Number:</strong>
            <input type="text" id="order_number" name="order_number" class="form-control" placeholder="Order  NUmber">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>
<br>



        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <!--<strong>Tracking_Url:</strong>-->
                <input type="text" name="tracking_url" class="form-control" placeholder="" style="display: none">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <!--<strong>Doctor_Validation Date:</strong>-->
                <input type="text" name="doctor_validation" class="form-control" placeholder="Doctor Validation"  style="display: none">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <!--<strong>Validators_Email:</strong>-->
                <input type="text" name="validators" class="form-control" placeholder="Validators"  style="display: none">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <!--<strong>Delivery_Date:</strong>-->
                <input type="text" name="delivery_date" class="form-control" placeholder="Patient Delivery Date" style="display: none">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <input type="text" name="followup_date" class="form-control" placeholder="Patient followup Date" style="display: none">
            </div>
        </div>    
</form>
@endsection
