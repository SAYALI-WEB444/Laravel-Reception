

function calculateTotalPrice(medicines,discount){

var medEntry = medicines.split(",");

var arrayLength = medEntry.length;
var totalPrice = 0;
for (var i = 0; i < arrayLength; i++) {
    var entry = medEntry[i].split(":");
    if(entry.length < 3 ){
        console.log("wrong entry");
    }else{

        totalPrice  = totalPrice + parseInt(entry[2]) ;
        console.log(totalPrice);
    }
}

 return totalPrice - ( discount * totalPrice/100);
}

function getCurrentDateTime(){
    var currentdate = new Date();
   return  currentdate.getDate() + "/"
    + (currentdate.getMonth()+1)  + "/"
    + currentdate.getFullYear() + "  "
    + currentdate.getHours() + ":"
    + currentdate.getMinutes() + ":"
    + currentdate.getSeconds();
}

function setupCreatePage(role, userEmail){
    $('#discount').on('change keyup paste',

        function(){
            $('#totalbill').val(calculateTotalPrice($('#medicines').val(),$('#discount').val()));
        }
    );

    datetimeString =getCurrentDateTime();

    $("#medicines").prop("readonly", true);
    $("#totalbill").prop("readonly", true);

    if($("#patient_enrol_date").val() ==""){
        $("#patient_enrol_date").val(datetimeString);
    }
    $("#patient_enrol_date").prop("readonly", true);





    $("#order_number").prop("readonly", true);

    $("#order_number").val( "OR-" + Math.random().toString(36).substring(4))




    if($("#business_developer").val() == "") {
        $("#business_developer").val(userEmail);
    }
    $("#business_developer").prop("readonly", true);

    if(role == "doctor") {
        if($("#doctor_name").val() == "") {
            $("#doctor_name").val(userEmail);
        }
        $("#doctor_name").prop("readonly", true);
    }


    $('#demo').multiselect({

        buttonTitle: function (options, select) {
            if (options.length === 0) {
                return this.nonSelectedText;
            }
            else {
                var selected = '';
                var delimiter = this.delimiterText;

                options.each(function () {
                    var label = ($(this).attr('label') !== undefined) ? $(this).attr('label') : $(this).text();
                    selected += label + delimiter;
                });
                //Remove trailing ,
                var tmpselected = selected.substr(0, selected.length - this.delimiterText.length);
                var discount = $('#discount').val();

                $('#medicines').val (tmpselected);
                $('#totalbill').val(calculateTotalPrice(tmpselected,discount));
                return tmpselected;
            }
        }

    })

    if ( role != "doctor"){
        //     echo "$('#medicines').hide();";
        $('.multiselect-native-select').hide();
        $('#doctor_consultation').hide();

    }else{
        $('#doctor_consultation').val(datetimeString);
        $('#doctor_consultation').prop('readonly', true);
    }
}

function setupEditPage(role) {


}







