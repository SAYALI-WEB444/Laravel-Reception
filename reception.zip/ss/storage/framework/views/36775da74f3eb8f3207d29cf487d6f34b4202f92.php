
<div class="fa-pull-left">
    <a class="btn btn-primary" href="<?php echo e(route('products.index')); ?>">Back</a>
</div>
<?php /**PATH C:\xampp\htdocs\ss\resources\views/home.blade.php ENDPATH**/ ?>