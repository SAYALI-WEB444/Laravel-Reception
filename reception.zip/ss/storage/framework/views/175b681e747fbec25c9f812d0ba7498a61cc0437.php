<?php $__env->startSection('content'); ?>


    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
    <span>
    <div class="row">
        <div class="col-lg-10 margin-tb">
            <div class="pull-right">
            </div>
            <br>
            <div class="pull-left">
            <a class="btn btn-success" href="<?php echo e(route('products.create')); ?>">Add Patient</a>
                   <a class="btn btn-success" href="<?php echo e(route('home')); ?>">Call</a>

                <!--<a class="btn buttons-excel buttons-html5 btn-default" tabindex="0" aria-controls="DataTables_Table_0" href="#"><span>Excel</span></a>-->
                <!--<a class="btn buttons-csv buttons-html5 btn-default" tabindex="0" aria-controls="DataTables_Table_0" href="#"><span>CSV</span></a>-->
            </div>
            <br>

            <br>
        </div>
    </div>

<div class="row">
    <div class="col-lg-10 margin-tb">
        <div class="pull-right">

    <form method="GET" action="">
        <div class="row">
            <div class="col-md-10">
                <input type="text" name="search" class="form-control" placeholder="Search Patient" value="<?php echo e(old('search')); ?>">
            </div>
            <div class="col-md-2">
                <button class="btn btn-success">Search</button>


            </div>
        </div>
        </form>
    <br></div>
    <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>


    <!--<table class="table table-bordered">-->

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <table class="table table-bordered data-table">

   <?php if(   !app('request')->input('search') || (

      ( $product->doctor_name == Auth::user()->email || $product->business_developer == Auth::user()->email) )
      ): ?>
                    <a class="btn btn-primary" href="<?php echo e(route('products.edit',$product->id )); ?>">Edit</a>
                <?php endif; ?>
   <br>
</br>
   <form action="" method="POST">

<tr>
            <th>No</th>
            <th>Patient_Name</th>
            <th>Patient_Mobile</th>
            <th>Patient_Address</th>
            <th>Status</th>
            <th>Business_Developer</th>
            <th>Doctor_Name</th>
            <th>Doctor_Consultation</th>
            <!--<th>Delivery</th>-->
            <th>Problem_of_Patient</th>
            <th>Patient_Medicines</th>
            <th>Total_Billing</th>
            <th>Mode_of_Payment</th>
            <th>Patient_Enrol_Date</th>
            <th>Discount</th>
            <th>Pincode</th>
            <th>State</th>
            <!--<th>Order_N</th>-->
            <th>Nearest_City</th>
            <th>Patient_Available</th>
            <th>To</th>
            <th>Tracking_Url</th>
            <th>Doctor_Validation</th>
            <th>Validators</th>
            <th>Delivery_Date</th>
            <th>Followup_Date</th>
            <th>Order_Number</th>
   </tr>
            <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($product->patient_name); ?></td>
            <td><?php echo e($product->patient_mobile); ?></td>
            <td><?php echo e($product->patient_address); ?></td>
            <td><?php echo e($product->status); ?></td>
            <td><?php echo e($product->business_developer); ?></td>
            <td><?php echo e($product->doctor_name); ?></td>
            <td><?php echo e($product->doctor_consultation); ?></td>
           <!-- <td><?php echo e($product->delivery); ?></td>-->
            <td><?php echo e($product->problem_of_patient); ?></td>
            <td><?php echo e($product->medicines); ?></td>
            <td><?php echo e($product->total_billing); ?></td>
            <td><?php echo e($product->mode_of_payment); ?></td>
            <td><?php echo e($product->patient_enrol_date); ?></td>
            <td><?php echo e($product->discount); ?></td>
            <td><?php echo e($product->pincode); ?></td>
            <td><?php echo e($product->state); ?></td>
           <!--<td><?php echo e($product->order_n); ?></td>-->
            <td><?php echo e($product->nearest_city); ?></td>
            <td><?php echo e($product->patient_available); ?></td>
            <td><?php echo e($product->to); ?></td>
            <td><?php echo e($product->tracking_url); ?></td>
            <td><?php echo e($product->doctor_validation); ?></td>
            <td><?php echo e($product->validators); ?></td>
            <td><?php echo e($product->delivery_date); ?></td>
            <td><?php echo e($product->followup_date); ?></td>
            <td><?php echo e($product->order_number); ?></td>



                    <?php echo csrf_field(); ?>
                    </form>



        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $products->links(); ?>


<?php $__env->stopSection(); ?>















<?php echo $__env->make('products.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ss\resources\views/products/index.blade.php ENDPATH**/ ?>