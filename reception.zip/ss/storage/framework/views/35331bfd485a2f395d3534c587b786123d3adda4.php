<?php $__env->startSection('content'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"
            xmlns="http://www.w3.org/1999/html"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.8.1/css/bootstrap-select.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.8.1/js/bootstrap-select.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="/path/to/src/jquery.multi-select.js"></script>
    <?php
    use App\Http\Controllers\RoleController;
    $roleObject = new RoleController();
    $role =  $roleObject -> getRole(Auth::user()->email);
    ?>

    <script>
        /*$(function(){
            $('#demo').multiselect();
        });*/

        $(window).load(
            $(function() {
                setupCreatePage(
                    <?php echo "'" . $role . "'" ?>
                );
                setupEditPage(
                    <?php echo "'" . $role . "'" ?>
                );

            })

        )
    </script>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <br>
                <h1>Edit Patient</h1>
            </div>
            <br>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('products.index')); ?>"> Back</a>
            </div>
        </div>
    </div>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('products.update',$product->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

         <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Patient_Name:</strong>
                    <input type="text" name="patient_name" value="<?php echo e($product->patient_name); ?>" class="form-control" placeholder="Enter Patient Name">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Patient_Mobile:</strong>
                    <input type="tel" name="patient_mobile" value="<?php echo e($product->patient_mobile); ?>"   maxlength="10" class="form-control" placeholder="Enter Patient Mobile Number">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Patient_Address:</strong>
                    <input type="text" name="patient_address" value="<?php echo e($product->patient_address); ?>" class="form-control" placeholder="Enetr Patient Patient Address">
                </div>
            </div>

               <!-- <div class="form-group">
                    <strong>Status:</strong>
                    <input type="text" name="status" value="<?php echo e($product->status); ?>" class="form-control" placeholder="">
                </div>
            </div>-->
             <div class="col-xs-12 col-sm-12 col-md-12">
                 <div class="form-group" <?php echo e($errors->has('status') ? 'has-error' : ''); ?>>
                     <strong>Status</strong>
                     <select class="form-control" name="status" value="<?php echo e('$product->status'); ?>">
                         <option selected></option>
                         <?php
                         if($role == "doctor"){

                             echo "
                                                    <option value='Validation done by Doctor (d) - set this status if you are telling price and medicines to patient and you are absolutely sure that patient is not going to refuse the delivery, otherwise set schedule for delivery'>Validation done by Doctor (d) - set this status if you are telling price and medicines to patient and you are absolutely sure that patient is not going to refuse the delivery, otherwise set schedule for delivery</option>
                                                    <option value='Consultation Done - Do Not Deliver Medicines'>Consultation Done - Do Not Deliver Medicines</option>
                                                    <option value='Call back'>Call back</option>
                                                    <option value='Patient not reachable (d) - retry 1'>Patient not reachable (d) - retry 1</option>
                                                    <option value='Patient not reachable (d) - retry 2'>Patient not reachable (d) - retry 2</option>
                                                    <option value='Patient not reachable (d) - retry 3'>Patient not reachable (d) - retry 3</option>
                                                    <option value='Ask for Reports'>Ask for Reports</option>

                                                    <option value='Reconvince Patient (d)'>ReConvince Patient (d)</option>";
                         }
                         echo "<option value='New'>New</option>
                                                    <option value='Followup'> Followup</option>
                                                    <option value='Duplicate Entry'>Duplicate Entry</option>";

                         ?>
                     </select>
                     <?php echo $errors->first('status', '<small class="text-danger">:message </small>'); ?>

                 </div>
             </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Business_Developer:</strong>
                    <input type="text" id="business_developer" name="business_developer" value="<?php echo e($product->business_developer); ?>" class="form-control" placeholder="">
                </div>
            </div>
             <div class="col-xs-12 col-sm-12 col-md-12">

                 <?php
                 if($role == "doctor"){
                     echo "
                                <div class='form-group'>
                                     <strong>Doctor_Name:</strong>
                                              <input type='email' id='doctor_name' name='doctor_name' value='" .
                         $product->doctor_name . "' class='form-control'>
                               </div>
                            ";
                 }else{


                     echo "

                                 <div  input type='email' id='doctor_name1' class='form-group' name='doctor_name1' >
                                                                    <strong> Doctor_Name<strong>
                                                                                    <select class='form-control' value='{{ product->doctor_name }}' name='doctor_name' id='doctor_name' >
                                                                                        <option selected>'{{ product->doctor_name }}'</option>
                                                                                        <option value='s@gmail.com'>s@gmail.com</option>
                                                                                        <option value='d@gmail.com'>d@gmail.com</option>
                                                                                        <option value='priya'>priya</option>
                                                                                        <option value='Namrata'>Namrata</option>
                                                                                    </select>

                                </div>
                               ";
                 } ?>
             </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Doctor_consultation:</strong>
                    <input type="text" id = "doctor_consultation" name="doctor_consultation" value="<?php echo e($product->doctor_consultation); ?>" class="form-control" placeholder="">
                </div>
            </div>
            <!--<div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Delivery:</strong>
                    <input type="text" name="delivery" value="<?php echo e($product->delivery); ?>" class="form-control" placeholder="">
                </div>
            </div>-->
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Problem_Of_Patient:</strong>
                    <input type="text" name="problem_of_patient" value="<?php echo e($product->problem_of_patient); ?>" class="form-control" placeholder="">
                </div>
            </div>



             <div class="col-xs-12 col-sm-12 col-md-12">
             <strong>Medicines:</strong><select id="demo" value="<?php echo e($product->medicines); ?>"multiple="multiple">
                 <option value="srdp talet:2 pack:200">srdp talet:2 pack:200</option>
                 <option value="srdp talet:3 pack:300">srdp talet:3 pack:300</option>
                 <option value="srdp talet:4 pack:400">srdp talet:4 pack:400</option>
                 <option value="srdp talet:5 pack:500">srdp talet:5 pack:500</option>
                 <option value="srdp oil:1   pack:100">srdp oil:1 pack:100</option>
                 <option value="potli:1 pack:50">potli:1 pack:50</option>
             </select>
                 <div class="form-group">
                     <input type="text" id="medicines" name="medicines" class="form-control" value="<?php echo e($product->medicines); ?>"  placeholder="">

                 </div>
             </div>
         <!--  <div class="col-xs-12 col-sm-12 col-md-12">
                 <div class="form-group">
                     <strong>Medicines:</strong>
                     <select name="medicines"class="selectpicker" value="<?php echo e($product->medicines); ?>" placeholder="Enter Medicines" id="medicines" multiple data-live-search="true">
                         <option>srdp talet:2 pack: 200</option>
                         <option>srdp talet:3 pack: 300</option>
                         <option>srdp talet:4 pack: 400</option>
                         <option>srdp talet:5 pack: 500</option>
                         <option>srdp oil</option>
                         <option>potli</option>-->



            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Total_Billing:</strong>
                    <input type="text" id="totalbill" name="total_billing" value="<?php echo e($product->total_billing); ?>" class="form-control" placeholder="">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Mode_Of_Payment:</strong>
                    <select class="form-control" name="mode_of_payment" id="ode_of_payment"  value="<?php echo e($product->mode_of_payment); ?>"placeholder="" >
                        <option value="COD">COD</option>
                        <option value="POD">POD</option>
                    </select>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Patient_Enrol_Date:</strong>
                    <input date="text" id="patient_enrol_date" name="patient_enrol_date" value="<?php echo e($product->patient_enrol_date); ?>" class="form-control" placeholder="">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Discount:</strong>
                    <input type="text" id="discount" name="discount" value="<?php echo e($product->discount); ?>" class="form-control" placeholder="">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Pincode:</strong>
                    <input type="text" name="pincode" value="<?php echo e($product->pincode); ?>" class="form-control">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>State:</strong>
                    <input type="text" name="state" value="<?php echo e($product->state); ?>" class="form-control" placeholder="">
                </div>
            </div>

           <!-- <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Order_N:</strong>
                    <input type="text" name="order_n" value="<?php echo e($product->order_n); ?>" class="form-control" placeholder="">
                </div>
            </div>-->

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Nearest_City:</strong>
                    <input type="text" name="nearest_city" value="<?php echo e($product->nearest_city); ?>" class="form-control" placeholder="">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Patient_Available:</strong>
                    <input type="text" name="patient_available" value="<?php echo e($product->patient_available); ?>" class="form-control" placeholder="">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>To:</strong>
                    <input type="text" name="to" value="<?php echo e($product->to); ?>" class="form-control" placeholder="">
                </div>
            </div>


            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Tracking_Url:</strong>
                    <input type="text" name="tracking_url" value="<?php echo e($product->tracking_url); ?>" class="form-control" placeholder="">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Doctors_validation Date:</strong>
                    <input type="text" name="doctor_validation" value="<?php echo e($product->doctor_validation); ?>" class="form-control" placeholder="">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong> Validators Email Id:</strong>
                    <input type="text" name="validators" value="<?php echo e($product->validators); ?>" class="form-control" placeholder="">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Delivery_Date:</strong>
                    <input type="text" name="delivery_date" value="<?php echo e($product->delivery_date); ?>" class="form-control" placeholder="">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Followup_Date:</strong>
                    <input type="date" name="followup_date" value="<?php echo e($product->followup_date); ?>" class="form-control" placeholder="" >
                </div>
            </div>

             <div class="col-xs-12 col-sm-12 col-md-12">
                 <div class="form-group">
                     <strong>Order_Number:</strong>
                     <input type="text" id="order_number" name="order_number" value="<?php echo e($product->order_number); ?>" class="form-control" placeholder="">
                 </div>
             </div>




                <script>
                    $(document).ready(function () {

                        $("#formABC").submit(function (e) {

                            //stop submitting the form to see the disabled button effect
                            e.preventDefault();

                            //disable the submit button
                            $("#Submit").attr("disabled", true);

                            //disable a normal button
                            $("#btnTest").attr("disabled", true);

                            return true;

                        });
                    });
                </script>


            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
         </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('products.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ss\resources\views/products/edit.blade.php ENDPATH**/ ?>